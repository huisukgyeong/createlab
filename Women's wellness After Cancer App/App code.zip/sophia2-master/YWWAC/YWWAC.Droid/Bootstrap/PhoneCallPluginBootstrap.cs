using MvvmCross.Platform.Plugins;

namespace YWWAC.Droid.Bootstrap
{
    public class PhoneCallPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.PhoneCall.PluginLoader>
    {
    }
}