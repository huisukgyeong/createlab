﻿using MvvmCross.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YWWAC.core.ViewModels
{
    public class InformationMenuViewModel : MvxViewModel
    {
        public MvxCommand NewsViewCommand
        {
            get
            {
                return new MvxCommand(() => ShowViewModel<NewsViewModel>());
            }
        }
    }
}