﻿namespace YWWAC.core.ViewModels
{
    public class BaseAdaptor<T>
    {
    }
}