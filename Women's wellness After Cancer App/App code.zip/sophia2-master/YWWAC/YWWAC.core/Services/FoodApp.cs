﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YWWAC.core.Services
{
    public static class FoodApp
    {
        public static string ApiKey = "b01b6c99c62ab12bd17f8d11202c5856";
        public static string AppId = "0402a484";
        public static string SearchEndpoint = "https://api.nutritionix.com/v1_1/search/";
        public static string NutritionEndpoint = "https://api.nutritionix.com/v1_1/item";
    }
}
